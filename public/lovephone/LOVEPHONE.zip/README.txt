LOVEPHONE - UYÊN 22 - GỬI ASTRA

index.html: web LOVEPHONE bản Pink Diary + Polaroid hiện tại.
YEU_CAU_CHO_ASTRA.md: yêu cầu chi tiết để Astra sửa căn mặt tai mèo / má hồng.

Gửi cả ZIP cho Astra và bảo Astra đọc YEU_CAU_CHO_ASTRA.md trước khi chỉnh code.

Dùng thử web trên GitHub Pages (HTTPS) hoặc localhost. Camera yêu cầu quyền truy cập.
