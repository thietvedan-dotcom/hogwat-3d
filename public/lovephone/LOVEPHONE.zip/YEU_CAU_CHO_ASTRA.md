# YÊU CẦU CHỈNH SỬA LOVEPHONE CHO ASTRA

## Phạm vi
Đọc và sửa file `index.html` đi kèm. Đây là phiên bản LOVEPHONE Pink Diary cần GIỮ NGUYÊN giao diện hiện tại. Không thiết kế lại màn hình khóa, màn hình chính, ảnh nền, app Messages, lời chúc, pháo giấy, app Photos hoặc hiệu ứng máy Polaroid in ảnh. Chỉ hoàn thiện tính năng filter AR trong app Camera (và sửa lỗi nhỏ liên quan nếu cần).

## Yêu cầu bắt buộc về nhận diện/căn mặt
1. Dùng MediaPipe Face Landmarker/Face Mesh hoặc thư viện tương đương chạy trực tiếp trên trình duyệt để theo dõi điểm khuôn mặt **theo thời gian thực**. Không được lấy tọa độ tỷ lệ cố định của toàn màn hình để đặt filter.
2. **Tai mèo:** đặt tai trái/phải trên đường viền đầu tương ứng, căn theo vị trí mắt, trán, thái dương và góc nghiêng đầu (roll). Kích thước co giãn theo độ lớn khuôn mặt; khi người dùng đi gần/xa, nghiêng đầu hoặc di chuyển, tai bám theo khuôn mặt với độ trễ thấp. Chừa viền tai tự nhiên; không che mắt.
3. **Blush:** má hồng ở đúng hai vùng má (dùng landmark má/điểm vùng dưới mắt), điều chỉnh theo góc nghiêng và kích thước mặt; làm mềm mép (gradient alpha), không dùng hai vòng tròn ở vị trí cố định.
4. **Bộ lọc kết hợp:** Tai mèo + blush cùng hoạt động, có thêm mũi/râu nếu phù hợp. Có 4 tùy chọn: Gốc / Tai mèo / Blush / Cả hai.
5. **Đúng hệ tọa độ:** video có `object-fit:cover`, camera selfie lật gương. Phải ánh xạ landmark từ tọa độ gốc video sang canvas theo tỷ lệ crop đúng, nhất quán giữa preview và ảnh chụp; camera trước/sau không bị đảo lệch. Không dùng DOM overlays cố định không khớp với ảnh đã lưu.
6. **Ảnh chụp:** chụp chính frame canvas đã compositing filter (đúng những gì người dùng đang thấy), không đặt lại filter bằng tọa độ tĩnh lúc lưu. Ảnh xuất PNG/JPEG phải giữ filter và hướng giống preview.
7. **Mượt:** phát hiện face landmark khoảng 15–30 FPS hoặc throttled hợp lý, render với requestAnimationFrame; làm mượt landmark nhẹ bằng exponential smoothing và không nhảy tai khi tracking chập chờn; tắt hoặc ẩn filter khi không phát hiện mặt.
8. **Điện thoại:** chạy Chrome Android + Safari iPhone (HTTPS/GitHub Pages); yêu cầu cấp quyền camera chỉ khi người dùng mở Camera, xử lý lỗi quyền và tải thư viện. Nếu thiếu model / không có Internet, báo lỗi rõ; vẫn cho phép chụp ảnh không filter.
9. **Riêng tư:** xử lý nhận diện mặt cục bộ trên thiết bị; không gửi ảnh/khuôn mặt đến máy chủ. Chỉ tải thư viện/model từ CDN rõ ràng.
10. **Sau chụp:** GIỮ NGUYÊN hiệu ứng camera Polaroid nhả ảnh từ từ và ảnh phát triển từ mờ sang rõ, rồi chuyển sang app Ảnh và lưu ảnh. Không đưa trở lại tính năng scrapbook / ghép mặt thiệp.

## Kiểm thử phải làm
- Ảnh selfie chính diện, nghiêng trái/phải 20–30 độ, lùi/tiến gần camera.
- Kiểm tra tâm tai so với trán và tâm blush so với má ở ít nhất 2 kích thước khuôn mặt.
- Đối chiếu bản preview và PNG lưu (không lệch tai, không lật ngược sai).
- Đổi camera trước/sau; không có khuôn mặt thì không vẽ filter lung tung.
- Mở app camera vài lần không rò rỉ stream/rAF; đóng app thì giải phóng camera.
- Chạy qua HTTPS / localhost; thử chụp → Polaroid nhả ảnh → app Photos.

## Tiêu chí hoàn thành
Trả lại `index.html` hoàn chỉnh, hoạt động trên GitHub Pages, giữ nguyên thiết kế Pink Diary của bản nguồn. Nếu chưa test được phần nào, nói rõ chưa test thay vì khẳng định thành công. Không dùng hình minh họa để thay cho tính năng camera thật.
